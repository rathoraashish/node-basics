var ashish = {
    name: "Ashish",
    role: "Web Developer",
    male: true
}

module.exports = ashish;