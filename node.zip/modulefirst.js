function simple() {
    console.log("This is a simple function");
}

let name = "Ashish";
let age = 22;

module.exports = { name, age, simple };