const modulefirst = require("./modulefirst");

// importing using common js module 
modulefirst.simple();
console.log(modulefirst.name);