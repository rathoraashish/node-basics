//Another promise
const calculate = (a, b, c) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (a < 0 || b < 0 || c < 0) {
                return reject("No result found");
            } else {
                resolve(a + b + c)
            }
        }, 1000)
    })
}

calculate(1, 2, 3).then((result) => {
    console.log(result);
}).catch((e) => {
    console.log(e);
})

//

const showPosts = async() => {
    const response = await fetch("https://jsonplaceholder.typicode.com/posts");
    const posts = await response.json();
    console.log(posts);
}

showPosts();