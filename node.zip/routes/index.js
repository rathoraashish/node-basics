const express = require('express');
const router = express.Router();

router.use('/sendmail', require('./sendmail'));
router.use('/user', require('./user'));

module.exports = router;