const fs = require("fs");

fs.writeFile(__dirname + "/" + "test.txt", 'This is wriiten by writeFile', function(err, data) {
    console.log("written to the file");
});

fs.readFile(__dirname + "/" + "example.json", 'utf8', function(err, data) {
    console.log("This is for example:", data);
});

// let filedata = fs.readFileSync(__dirname + "/" + "test.txt", 'utf8');
// console.log(filedata);